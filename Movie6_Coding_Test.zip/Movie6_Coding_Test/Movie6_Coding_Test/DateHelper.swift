//
//  DateHelper.swift
//  Movie6_Coding_Test
//
//  Created by Cheuk Long on 31/7/2021.
//

import Foundation
import UIKit

extension Int{
    func convertIntToDate() -> [String]{
        let timeInterval = TimeInterval(self)

        // create NSDate from Double (NSTimeInterval)
        let myNSDate = Date(timeIntervalSince1970: timeInterval)
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let getDate = (dateFormatter.string(from: myNSDate))
        
        return getDate.components(separatedBy: "-")
    }
}
