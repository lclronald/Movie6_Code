//
//  ViewController.swift
//  Movie6_Coding_Test
//
//  Created by Cheuk Long on 29/7/2021.
//

import UIKit
import RxSwift
import RxCocoa

struct Movie: Codable{
    let uuid: String
    let name: String
    let openDate : Int?
    let poster : String
    let rating : Double
    let likeCount: Int
    let reviewCount : Int
    let duration : Int
    
    static var Max_Rating = 5
}

class MovieViewModel{
    var items = PublishSubject<[Movie]>()
    var movie = [Movie]()
    
    func fetchMovie(){
        if let url = URL(string: "https://jsonkeeper.com/b/WTPZ") {
            URLSession.shared.dataTask(with: url) { data, response, error in
                if let data = data {
                    let jsonDecoder = JSONDecoder()
                    

                    do {
                        let parsedJSON = try jsonDecoder.decode([Movie].self, from: data)
                        
                        self.movie = parsedJSON
                        self.items.onNext(self.movie)
                        self.items.onCompleted()

                    } catch {
                        print(error)
                    }
                }
            }.resume()
        }
        
    }
    
}
class MovieListVC: UIViewController,UISearchBarDelegate {
    private var movieModel = MovieViewModel()
    private var bag = DisposeBag()
    
    var dataForm = UIBarButtonItem()
    var searchBtn = UIBarButtonItem()
    
    private let MovieSearchBar : UISearchBar = {
        let searchBar = UISearchBar()

        searchBar.searchBarStyle = UISearchBar.Style.default
        searchBar.barTintColor = .black
        searchBar.placeholder = "Search Movie..."
        UITextField.appearance(whenContainedInInstancesOf: [UISearchBar.self]).defaultTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        searchBar.sizeToFit()
        searchBar.isTranslucent = false
        
        return searchBar
    }()
    var searchBarHeight = NSLayoutConstraint()
    
    private let MovieTableview : UITableView = {
        let table = UITableView()
        table.backgroundColor = .black
        table.register(UINib(nibName: "MovieTableCellTableViewCell", bundle: nil), forCellReuseIdentifier: "cell")
        return table
    }()
    
    private let MovieCollectioview : UICollectionView = {
        var collection: UICollectionView!
        let layout = UICollectionViewFlowLayout()
        collection = UICollectionView(frame: .zero, collectionViewLayout: layout)
        layout.scrollDirection = .vertical
        collection.backgroundColor = .black
        collection.register(UINib(nibName: "MovieCollectionCell", bundle: nil), forCellWithReuseIdentifier: "collection_cell")
        
        return collection
    }()
    
    private var isTableForm : Bool = true{
        didSet{
            if isTableForm{
                MovieTableview.isHidden = false
                MovieCollectioview.isHidden = true
                dataForm.image = UIImage(named: "Table-Form")?.withRenderingMode(.alwaysOriginal)
            } else {
                MovieTableview.isHidden = true
                MovieCollectioview.isHidden = false
                dataForm.image = UIImage(named: "Grid-Form")?.withRenderingMode(.alwaysOriginal)

            }
            
        }
    }
    
 
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("Load view")
        
        searchBtn = UIBarButtonItem(image: UIImage(systemName: "magnifyingglass")?.withRenderingMode(.alwaysTemplate), style: .plain, target: self, action: #selector(expandSeachBar))
        searchBtn.tintColor = .white
        dataForm = UIBarButtonItem(image: UIImage(named: "Table-Form")?.withRenderingMode(.alwaysOriginal), style: .plain, target: self, action: #selector(ChangeDisplayForm))
        
        
        navigationItem.rightBarButtonItems = [dataForm,searchBtn]
        navigationController?.navigationBar.barTintColor = .init(red: CGFloat(26/255), green: CGFloat(26/255), blue: CGFloat(26/255), alpha: 1)
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.white]
        title = "電影"
        
        MovieSearchBar.delegate = self
        view.addSubview(MovieSearchBar)
        
        
        
        MovieSearchBar.translatesAutoresizingMaskIntoConstraints = false
        MovieSearchBar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 5).isActive = true
        MovieSearchBar.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0).isActive = true
        MovieSearchBar.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: 0).isActive = true
        searchBarHeight = MovieSearchBar.heightAnchor.constraint(equalToConstant: 0)
        searchBarHeight.isActive = true
        
        
        
        
        view.addSubview(MovieTableview)
        
        MovieTableview.frame = CGRect(x: 0, y: 0, width: 0, height: 0)
        MovieTableview.translatesAutoresizingMaskIntoConstraints = false
        MovieTableview.topAnchor.constraint(equalTo: MovieSearchBar.bottomAnchor, constant: 5).isActive = true
        MovieTableview.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0).isActive = true
        MovieTableview.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: 0).isActive = true
        MovieTableview.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: 0).isActive = true
        MovieTableview.keyboardDismissMode = .onDrag
        bindTableData()
        
        
        view.addSubview(MovieCollectioview)
        MovieCollectioview.translatesAutoresizingMaskIntoConstraints = false
        MovieCollectioview.topAnchor.constraint(equalTo: MovieSearchBar.bottomAnchor, constant: 5).isActive = true
        MovieCollectioview.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0).isActive = true
        MovieCollectioview.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: 0).isActive = true
        MovieCollectioview.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: 0).isActive = true
        MovieCollectioview.isHidden = true
        MovieCollectioview.keyboardDismissMode = .onDrag
        bindCollectionData()
        
        
        
    }
    
    @objc func ChangeDisplayForm(){
        isTableForm = !isTableForm
    }
    
    @objc func expandSeachBar(){
        searchBarHeight.isActive = false
        searchBarHeight = MovieSearchBar.heightAnchor.constraint(equalToConstant: 44)
        searchBarHeight.isActive = true
        let animator = UIViewPropertyAnimator(duration:0.3, curve: .linear) {
            self.view.layoutIfNeeded()
        }
        animator.startAnimation()
        
        runSearchBar_TableView()
        runSearchBar_CollectionView()
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func bindTableData(){
        
        MovieTableview.dataSource = nil
        MovieTableview.delegate = nil
        
        
        movieModel.items.asObservable().bind(to: MovieTableview.rx.items) { (tableView,row, element) in
            let indexPath = IndexPath(row: row, section: 0)
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell",for: indexPath) as! MovieTableCell
            cell.configure(url: element.poster)
            
            cell.ratingLbl.text = String(round(element.rating * 10)/10.0)
            cell.movieTitle.text = element.name
            cell.likeLbl.text = String(element.likeCount)
            cell.cmLbl.text = String(element.reviewCount)
            
            
            for i in 1...Movie.Max_Rating{
                var starImg = UIImage()
                if i <= Int(element.rating){
                    starImg = UIImage(named:"fill-star")!
                } else if element.rating - Double(i - 1) > 0 {
                    starImg = UIImage(named:"half-star")!
                } else {
                    starImg = UIImage(named:"not-star")!
                }
                
                cell.rateStarImg[i-1].image = starImg
            }
            
            let date = element.openDate?.convertIntToDate()
            
            if let date = date{
                cell.dateLbl.text = "\(date[0])年\(date[1])月\(date[2])日"
            } else {
                cell.dateLbl.isHidden = true
            }
            
            return cell
            
        }.disposed(by: bag)
        
        
        
        MovieTableview.rx.modelSelected(Movie.self).bind { movie in
            print(movie.name)
        }.disposed(by: bag)
        
        movieModel.fetchMovie()
        
        MovieTableview.rx.setDelegate(self).disposed(by: bag)
    }
    
    func bindCollectionData(){
        
        self.MovieCollectioview.delegate = nil
        self.MovieCollectioview.dataSource = nil
        movieModel.items.asObservable().bind(to: MovieCollectioview.rx.items) { (collectionView,row, element) in
            let indexPath = IndexPath(row: row, section: 0)
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collection_cell",for: indexPath) as! MovieCollectionCell
            cell.configure(url: element.poster)
            cell.ratingLbl.text = String(round(element.rating * 10)/10.0)
            cell.movieTitle.text = element.name
            cell.likeLbl.text = String(element.likeCount)
            cell.cmLbl.text = String(element.reviewCount)
            return cell
            
        }.disposed(by: bag)
        
        
        
        MovieCollectioview.rx.modelSelected(Movie.self).bind { movie in
            print(movie.name)
        }.disposed(by: bag)
        
        movieModel.fetchMovie()
        
        MovieCollectioview.rx.setDelegate(self).disposed(by: bag)
    }
    
    func runSearchBar_TableView(){
        self.MovieTableview.delegate = nil
        self.MovieTableview.dataSource = nil
        MovieSearchBar.rx.text.orEmpty.throttle(.milliseconds(300),scheduler: MainScheduler.instance).distinctUntilChanged().map({ query in
            self.movieModel.movie.filter({
                movie in
                query.isEmpty || movie.name.lowercased().contains(query.lowercased())
            })
        }).bind(to: MovieTableview.rx.items(cellIdentifier: "cell", cellType: MovieTableCell.self)){
            (tv,element,cell) in
            cell.configure(url: element.poster)
            cell.ratingLbl.text = String(round(element.rating * 10)/10.0)
            cell.movieTitle.text = element.name
            cell.likeLbl.text = String(element.likeCount)
            cell.cmLbl.text = String(element.reviewCount)
            
            for i in 1...Movie.Max_Rating{
                var starImg = UIImage()
                if i <= Int(element.rating){
                    starImg = UIImage(named:"fill-star")!
                } else if element.rating - Double(i - 1) > 0 {
                    starImg = UIImage(named:"half-star")!
                } else {
                    starImg = UIImage(named:"not-star")!
                }
                
                cell.rateStarImg[i-1].image = starImg
            }
            
            let date = element.openDate?.convertIntToDate()
            
            if let date = date{
                cell.dateLbl.text = "\(date[0])年\(date[1])月\(date[2])日"
            } else {
                cell.dateLbl.isHidden = true
            }
        }.disposed(by: bag)
        
        MovieTableview.rx.setDelegate(self).disposed(by: bag)
    }
    
    func runSearchBar_CollectionView(){
        self.MovieCollectioview.delegate = nil
        self.MovieCollectioview.dataSource = nil
        
        
        MovieSearchBar.rx.text.orEmpty.throttle(.milliseconds(300),scheduler: MainScheduler.instance).distinctUntilChanged().map({ query in
            self.movieModel.movie.filter({
                movie in
                query.isEmpty || movie.name.lowercased().contains(query.lowercased())
            })
        }).bind(to: MovieCollectioview.rx.items(cellIdentifier: "collection_cell", cellType: MovieCollectionCell.self)){
            (tv,element,cell) in
            
            cell.configure(url: element.poster)
            cell.ratingLbl.text = String(round(element.rating * 10)/10.0)
            cell.movieTitle.text = element.name
            cell.likeLbl.text = String(element.likeCount)
            cell.cmLbl.text = String(element.reviewCount)
            
        }.disposed(by: bag)
        
        MovieCollectioview.rx.setDelegate(self).disposed(by: bag)
    }
    
    
}

extension MovieListVC: UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
}

extension MovieListVC: UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = collectionView.bounds.width
        let cellWidth = (width - 20) / 3 // compute your cell width
        return CGSize(width: cellWidth, height: cellWidth * 2)
    }
}




