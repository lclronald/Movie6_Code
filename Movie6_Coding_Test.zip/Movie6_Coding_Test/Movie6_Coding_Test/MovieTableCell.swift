//
//  MovieTableCellTableViewCell.swift
//  Movie6_Coding_Test
//
//  Created by Cheuk Long on 30/7/2021.
//

import UIKit

class MovieTableCell: UITableViewCell {

    @IBOutlet weak var movieImg: UIImageView!
    @IBOutlet weak var ratingLbl: UILabel!
    @IBOutlet weak var rateStackview: UIStackView!
    
    @IBOutlet var rateStarImg: [UIImageView]!
    @IBOutlet weak var movieTitle: UILabel!
    @IBOutlet weak var likeImg: UIImageView!
    @IBOutlet weak var likeLbl: UILabel!
    @IBOutlet weak var cmImg: UIImageView!
    @IBOutlet weak var cmLbl: UILabel!
    @IBOutlet weak var dateLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        movieTitle.sizeToFit()
        movieImg.contentMode = .scaleToFill
        likeImg.contentMode = .scaleToFill
        cmImg.contentMode = .scaleToFill

        for starImg in rateStarImg{
            starImg.contentMode = .scaleToFill
        }
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func configure(url: String){
        movieImg.layer.cornerRadius = 5
        movieImg.load(urlString: url)
    }
}
