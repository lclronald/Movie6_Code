//
//  MovieCollectionCell.swift
//  Movie6_Coding_Test
//
//  Created by Cheuk Long on 1/8/2021.
//

import UIKit

class MovieCollectionCell: UICollectionViewCell {

    @IBOutlet weak var movieImg: UIImageView!
    @IBOutlet weak var movieTitle: UILabel!
    @IBOutlet weak var rateStarImg: UIImageView!
    @IBOutlet weak var ratingLbl: UILabel!
    @IBOutlet weak var likeImg: UIImageView!
    @IBOutlet weak var likeLbl: UILabel!
    @IBOutlet weak var cmImg: UIImageView!
    @IBOutlet weak var cmLbl: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        movieTitle.sizeToFit()
        movieImg.contentMode = .scaleToFill
        likeImg.contentMode = .scaleToFill
        cmImg.contentMode = .scaleToFill
    }

    func configure(url: String){
        movieImg.layer.cornerRadius = 5
        movieImg.load(urlString: url)
    }
    

}
